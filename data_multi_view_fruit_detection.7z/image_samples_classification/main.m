clc;
clear;

image_dir = 'E:/Caiwang_ZHENG/xyz_total_addcenter_819_Final/data_extraction/';

folder = 'E:/Caiwang_ZHENG/xyz_total_addcenter_819_Final/image_samples_classification/';
cd(folder)

load Strawberry_Information.mat;

strawberry_image = cell2mat(Strawberry_Information(:,2));
strawberry_class = cell2mat(Strawberry_Information(:,7));

for i = 1:6
    sub_folder = num2str(i);
    mkdir(sub_folder);
    disp(i);
    p = find(strawberry_class == i);
    for j = 1:length(p)
        image_folder_b = [image_dir,num2str(strawberry_image(p(j)))];
        image_folder_n = [folder,sub_folder,'/',num2str(strawberry_image(p(j)))];
        copyfile(image_folder_b,image_folder_n);
    end
end